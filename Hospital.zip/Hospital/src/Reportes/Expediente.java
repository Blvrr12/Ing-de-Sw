package Reportes;

import Clases.Conexion;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.filechooser.FileSystemView;

public class Expediente {
    Connection con;
    Conexion cn = new Conexion();
    PreparedStatement ps;
    ResultSet rs;

    public void generarPDFExpediente(int IDPaciente) {
    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
        // Fecha actual
        Date date = new Date();
        String url = FileSystemView.getFileSystemView().getDefaultDirectory().getPath();
        File salida = new File(url + "/ExpedientePaciente.pdf");
        FileOutputStream archivo = new FileOutputStream(salida);
        Document doc = new Document();
        PdfWriter.getInstance(doc, archivo);
        doc.open();

        // Agregar logo
        try {
            Image img = Image.getInstance(getClass().getResource("/Images/logo_pdf.png"));
            img.scaleToFit(100, 100);
            img.setAlignment(Element.ALIGN_LEFT);
            doc.add(img);
        } catch (Exception e) {
            System.out.println("No se pudo cargar el logo: " + e.getMessage());
        }

        // Fecha
        Paragraph fecha = new Paragraph();
        Font negrita = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD, BaseColor.BLUE);
        fecha.add(Chunk.NEWLINE);
        fecha.add("Fecha de generación: " + new SimpleDateFormat("dd/MM/yyyy").format(date) + "\n\n");
        doc.add(fecha);

        // Encabezado
        Paragraph encabezado = new Paragraph();
        encabezado.setFont(negrita);
        encabezado.add("Expediente Médico\n\n");
        encabezado.setAlignment(Element.ALIGN_CENTER);
        doc.add(encabezado);

        // Consulta SQL
        String sql = """
            SELECT
                ID_Paciente,
                Paciente_Nombres,
                Paciente_Apellidos,
                Paciente_Edad,
                Paciente_Telefono,
                Paciente_Tipo_Sangre,
                Fecha_Cita,
                Descripcion_Consulta,
                Diagnostico,
                Receta,
                Medico_Nombres,
                Medico_Apellidos
            FROM expediente
            WHERE ID_Paciente = ?;
        """;

        con = cn.getConexion();
        ps = con.prepareStatement(sql);
        ps.setInt(1, IDPaciente);
        rs = ps.executeQuery();

        if (rs.next()) {
            // Datos del paciente
            Paragraph datosPaciente = new Paragraph();
            datosPaciente.add("ID Paciente: " + rs.getInt("ID_Paciente") + "\n");
            datosPaciente.add("Nombres: " + rs.getString("Paciente_Nombres") + "\n");
            datosPaciente.add("Apellidos: " + rs.getString("Paciente_Apellidos") + "\n");
            datosPaciente.add("Edad: " + rs.getInt("Paciente_Edad") + "\n");
            datosPaciente.add("Teléfono: " + rs.getString("Paciente_Telefono") + "\n");
            datosPaciente.add("Tipo de Sangre: " + rs.getString("Paciente_Tipo_Sangre") + "\n\n");
            doc.add(datosPaciente);

            // Datos del médico
            Paragraph datosMedico = new Paragraph();
            datosMedico.add("Nombre Médico: " + rs.getString("Medico_Nombres") + " " + rs.getString("Medico_Apellidos") + "\n\n");
            doc.add(datosMedico);

            // Detalles de la consulta
            PdfPTable tablaConsulta = new PdfPTable(2);
            tablaConsulta.setWidthPercentage(100);
            tablaConsulta.setSpacingBefore(10f);
            tablaConsulta.setSpacingAfter(10f);
            tablaConsulta.addCell(new PdfPCell(new Phrase("Fecha de Cita", negrita)));
            String fechaCita = rs.getString("Fecha_Cita") != null ? rs.getString("Fecha_Cita") : "No disponible";
            tablaConsulta.addCell(fechaCita);
            tablaConsulta.addCell(new PdfPCell(new Phrase("Descripción de Consulta", negrita)));
            tablaConsulta.addCell(rs.getString("Descripcion_Consulta") != null ? rs.getString("Descripcion_Consulta") : "No disponible");
            tablaConsulta.addCell(new PdfPCell(new Phrase("Diagnóstico", negrita)));
            tablaConsulta.addCell(rs.getString("Diagnostico") != null ? rs.getString("Diagnostico") : "No disponible");
            tablaConsulta.addCell(new PdfPCell(new Phrase("Receta", negrita)));
            tablaConsulta.addCell(rs.getString("Receta") != null ? rs.getString("Receta") : "No disponible");
            doc.add(tablaConsulta);
        } else {
            Paragraph noDatos = new Paragraph();
            noDatos.add("No se encontraron datos para el paciente con ID: " + IDPaciente);
            doc.add(noDatos);
        }

        doc.close();
        Desktop.getDesktop().open(salida); // Abre el archivo PDF generado
    } catch (Exception e) {
        System.out.println("Error al generar el expediente en PDF: " + e.getMessage());
    } finally {
        try {
            if (rs != null) rs.close();
            if (ps != null) ps.close();
            if (con != null) con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
}
