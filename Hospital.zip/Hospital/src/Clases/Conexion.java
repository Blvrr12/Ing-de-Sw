package Clases;

import java.sql.*;
import javax.swing.JOptionPane;
     /**
     * @yeudi
     */
public class Conexion {
    public static Connection con;
    public static Statement state, state1;
    public static ResultSet result, result1;
    
    
    public void Conectar(String user, String pass) throws SQLException, ClassNotFoundException {
    String url = "jdbc:mysql://localhost/Clinica?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    con = DriverManager.getConnection(url, "root", "12345");

    state = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
    JOptionPane.showMessageDialog(null, "Conexión Establecida", "Conexión Establecida", JOptionPane.INFORMATION_MESSAGE);
   }
    public static ResultSet consulta(String sql) throws SQLException {
        // Crear un Statement para realizar la consulta
        state1 = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        result1 = state1.executeQuery(sql); 
        return result1;
    }
    public Object conexion() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
}
