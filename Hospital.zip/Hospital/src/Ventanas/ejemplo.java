
package Ventanas;

import java.util.Arrays;
import java.util.List;

/**
 *
 * @author yeudi
 */

//que es una expresion lamda 
//que es lo que hace stream 
//que es un metodo de referencia 

public class ejemplo {
    
    public static void main(String[] args) {
       
    List <String> alumnitos = Arrays.asList("Juan","Pedro","Mama","Mano");
       for(int x=0; x<=alumnitos.size(); x++){
       System.out.println(alumnitos.get(x));
       }
       
       
       for(String nombre : alumnitos){
           System.out.println((nombre));   
       }
       alumnitos.forEach((nombre)-> System.out.println(nombre));
       alumnitos.forEach(System.out::println);
       
       
       for(String nombre : alumnitos){
           if(nombre.charAt(0)=='M'){
               System.err.println(nombre);
               
               
//        alumnitos.stream.filter(nombre)
           }
       }
    }
}