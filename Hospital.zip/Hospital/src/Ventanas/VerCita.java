package Ventanas;

import Clases.Cita;
import Clases.Conexion;
import static Clases.Medico.resultado;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @yeudi
 */
public class VerCita extends javax.swing.JInternalFrame {

    public VerCita() {
        initComponents();
        jTable1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        cmbBusc = new javax.swing.JComboBox();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setTitle("Ver Cita");
        addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
            public void internalFrameActivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosed(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosing(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeactivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeiconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameIconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameOpened(javax.swing.event.InternalFrameEvent evt) {
                formInternalFrameOpened(evt);
            }
        });

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/1439253074_power_off.png"))); // NOI18N
        jButton2.setText("Cancelar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/1435355601_sign-error.png"))); // NOI18N
        jButton3.setText("Salir");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Noto Sans", 1, 12)); // NOI18N
        jLabel1.setText("Buscar:");

        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarKeyReleased(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTable1.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(jTable1);

        cmbBusc.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Paciente", "Medico" }));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 670, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(4, 4, 4)
                        .addComponent(cmbBusc, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtBuscar))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButton2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton3)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbBusc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 364, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2)
                    .addComponent(jButton3))
                .addContainerGap())
        );

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        setBounds(0, 0, 705, 510);
    }// </editor-fold>//GEN-END:initComponents

    public void ActDes() {

    int Fila = jTable1.getSelectedRow();
    int Col = 5; // Ajustado al índice correcto de la columna "Estado"

    if (Fila >= 0) {
        int ID = Integer.parseInt(model.getValueAt(Fila, 0).toString());
        String Estado = model.getValueAt(Fila, Col).toString(); // Ahora usa el índice correcto

        if (Estado.equalsIgnoreCase("Pendiente")) {
            Cita.Cancelar_Cita(ID); // Cancelar la cita
        } else if (Estado.equalsIgnoreCase("Atendida")) {
            JOptionPane.showMessageDialog(this, "Ya se ha atendido esta cita",
                    "Atendida", JOptionPane.ERROR_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Ya ha cancelado esta cita anteriormente",
                    "Cancelada", JOptionPane.ERROR_MESSAGE);
        }
        CargarDatos();
    } else {
        JOptionPane.showMessageDialog(this, "Debe seleccionar la cita a cancelar",
                "Seleccione", JOptionPane.ERROR_MESSAGE);
    }
}

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        ActDes();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    public void CargarDatos() {

    model.setRowCount(0);

    // Encabezados de la tabla
    String[] Header = {"No.", "Medico", "Fecha", "Hora", "Paciente", "Estado"};
    model.setColumnIdentifiers(Header);

    String[] Datos = new String[6];

    try {
        // Consulta corregida
        resultado = Conexion.consulta("SELECT ID_Cita, Nombres_Med, Apellidos_Med, Fecha_Cita, Hora_Cita, Nombres_Pac, Apellidos_Pac, Estado FROM CitaV");

        while (resultado.next()) {
            // ID de la cita
            Datos[0] = String.valueOf(resultado.getInt(1));
            
            // Nombre del médico
            String Medico = "Dr. " + resultado.getString(2).trim() + " " + resultado.getString(3).trim();
            Datos[1] = Medico;
            
            // Fecha de la cita
            SimpleDateFormat SDF = new SimpleDateFormat("dd-MMM-yyyy");
            Date Fecha = resultado.getDate(4);
            Datos[2] = SDF.format(Fecha);
            
            // Hora de la cita
            Datos[3] = resultado.getString(5);
            
            // Nombre del paciente
            String Paciente = resultado.getString(6).trim() + " " + resultado.getString(7).trim();
            Datos[4] = Paciente;
            
            // Estado de la cita
            Datos[5] = resultado.getString(8);

            // Agregar los datos a la tabla
            model.addRow(Datos);
        }
    } catch (SQLException ex) {
        // Mostrar mensaje de error en caso de excepción
        JOptionPane.showMessageDialog(this, "Error al cargar citas: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }

    // Asignar el modelo a la tabla
    jTable1.setModel(model);
}



    private void formInternalFrameOpened(javax.swing.event.InternalFrameEvent evt) {//GEN-FIRST:event_formInternalFrameOpened
        CargarDatos();
    }//GEN-LAST:event_formInternalFrameOpened

    public void Buscar(){
        
         String Buscar = txtBuscar.getText();
         
             model.setRowCount(0);
             
        String[] Header = {"No.", "Medico", "Fecha", "Dia", "Hora", "Paciente", "Estado"};
        model.setColumnIdentifiers(Header);

        String[] Datos = new String[7];

        try {

            if(cmbBusc.getSelectedIndex()==0){
            resultado = Conexion.consulta("Select ID_Cita,Nombres_Med,Apellidos_Med,"
                    + "Fecha_Cita,Dia_Cita,Hora_Cita,Nombres,Apellidos,Estado from CitaV "
                    + "where Nombres like '%"+Buscar+"%' "
                    + "or Apellidos like '%"+Buscar+"%'");
            }
            
            
            if(cmbBusc.getSelectedIndex()==1){
            resultado = Conexion.consulta("Select ID_Cita,Nombres_Med,Apellidos_Med,"
                    + "Fecha_Cita,Dia_Cita,Hora_Cita,Nombres,Apellidos,Estado from CitaV "
                    + "where Nombres_Med like '%"+Buscar+"%' "
                    + "or Apellidos_Med like '%"+Buscar+"%'");
            }
            

            while (resultado.next()) {
                Datos[0] = String.valueOf(resultado.getInt(1));
                String Medico = "Dr. " + resultado.getString(2).trim() + " " + resultado.getString(3).trim();
                Datos[1] = Medico;
                SimpleDateFormat SDF = new SimpleDateFormat("dd-MMM-yyyy");
                Date Fecha = resultado.getDate(4);
                Datos[2] = SDF.format(Fecha);
                Datos[3] = resultado.getString(5);
                Datos[4] = resultado.getString(6);
                String Paciente = resultado.getString(7).trim() + " " + resultado.getString(8).trim();
                Datos[5] = Paciente;
                Datos[6] = resultado.getString(9);

                model.addRow(Datos);
            }

        } catch (SQLException ex) {

        }

        jTable1.setModel(model);
         
         
    }
    
    private void txtBuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyReleased
        Buscar();        
    }//GEN-LAST:event_txtBuscarKeyReleased

    DefaultTableModel model = new DefaultTableModel() {

        @Override
        public boolean isCellEditable(int row, int column) {

            return false;
        }

    };
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox cmbBusc;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField txtBuscar;
    // End of variables declaration//GEN-END:variables
}
