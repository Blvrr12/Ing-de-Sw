package Ventanas;

import Clases.Conexion;
import Clases.Paciente;
import java.io.File;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JasperViewer;
import Reportes.Expediente;


/**
 *
 * @yeudi
 */
public class VerPaciente extends javax.swing.JInternalFrame {

    public VerPaciente() {
        initComponents();
        jTable1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setTitle("Ver Paciente");
        addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
            public void internalFrameActivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosed(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosing(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeactivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeiconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameIconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameOpened(javax.swing.event.InternalFrameEvent evt) {
                formInternalFrameOpened(evt);
            }
        });

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/1435355589_floppy.png"))); // NOI18N
        jButton2.setText("Modificar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/1435355601_sign-error.png"))); // NOI18N
        jButton3.setText("Salir");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Noto Sans", 1, 12)); // NOI18N
        jLabel1.setText("Buscar:");

        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarKeyReleased(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTable1.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(jTable1);

        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/1439253074_power_off.png"))); // NOI18N
        jButton4.setText("Activar/Desactivar");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/1436145553_copy.png"))); // NOI18N
        jButton5.setText("Ver Expediente");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 670, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtBuscar)
                        .addGap(77, 77, 77))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButton5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton3)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 364, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2)
                    .addComponent(jButton3)
                    .addComponent(jButton4)
                    .addComponent(jButton5))
                .addContainerGap())
        );

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        setBounds(0, 0, 705, 510);
    }// </editor-fold>//GEN-END:initComponents

    public void Expediente(int ID_P, String Paciente) {

        Map<String, Object> parametros = new HashMap<String, Object>();
        parametros.put("IDPaciente", ID_P);
        File miDir = new File("");
        String reporte = miDir.getAbsolutePath() + "/src/Reportes/Expediente.jasper";
        JasperPrint jp = null;
        try {
            jp = JasperFillManager.fillReport(reporte, parametros, Conexion.con);
        } catch (JRException ex) {
        }

        JasperViewer view = new JasperViewer(jp, false);
        view.setTitle("Expediente - " + Paciente.trim());

        view.setZoomRatio((float) 0.95);
        view.setVisible(true);

        view.setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);
        view.toFront();

    }

    public void Modificar() {

        int Fila = jTable1.getSelectedRow();
        if (Fila >= 0) {
            int ID = Integer.parseInt(model.getValueAt(Fila, 0).toString());

            ModificarPaciente MP = new ModificarPaciente(null, true);
            MP.CargarDatos(ID);
            MP.setVP(this);
            MP.setVisible(true);

        } else {
            JOptionPane.showMessageDialog(this, "Debe seleccionar el registro a modificar",
                    "Seleccione", JOptionPane.ERROR_MESSAGE);
        }
    }
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        Modificar();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        this.dispose();     
    }//GEN-LAST:event_jButton3ActionPerformed

    ResultSet resultado;

    public void CargarDatos() {
        model.setRowCount(0);

        String[] Header = {"No.", "Nombres", "Apellidos", "Peso", "Altura",
            "Edad", "Telefono", "Alergias", "Enfermedades", "Tipo Sangre", "Estado"};
        model.setColumnIdentifiers(Header);
        String[] Datos = new String[11];

        try {

            resultado = Conexion.consulta("Select * from Paciente");
            while (resultado.next()) {
                Datos[0] = String.valueOf(resultado.getInt(1));
                Datos[1] = resultado.getString(2);
                Datos[2] = resultado.getString(3);
                Datos[3] = String.valueOf(resultado.getFloat(4));
                Datos[4] = String.valueOf(resultado.getFloat(5));
                Datos[5] = String.valueOf(resultado.getInt(6));
                Datos[6] = resultado.getString(7);
                Datos[7] = resultado.getString(8);
                Datos[8] = resultado.getString(9);
                Datos[9] = resultado.getString(10);

                boolean Estado = resultado.getBoolean(11);
                String Estate = "Inactivo";

                if (Estado) {
                    Estate = "Activo";
                }
                Datos[10] = Estate;
                model.addRow(Datos);
            }
        } catch (SQLException ex) {
        }
        jTable1.setModel(model);
    }

    private void formInternalFrameOpened(javax.swing.event.InternalFrameEvent evt) {//GEN-FIRST:event_formInternalFrameOpened

        CargarDatos();
// TODO add your handling code here:
    }//GEN-LAST:event_formInternalFrameOpened

    public void ActDes() {
    int Fila = jTable1.getSelectedRow();
    int Col = 10; // Columna donde está el estado del paciente

    if (Fila >= 0) {
        int ID = Integer.parseInt(model.getValueAt(Fila, 0).toString()); // ID del paciente
        String Estado = model.getValueAt(Fila, Col).toString(); // Estado actual

        if (Estado.equalsIgnoreCase("Activo")) {
            Paciente.Desactivar_Paciente(ID); // Llama al método para desactivar el paciente
            model.setValueAt("Inactivo", Fila, Col); // Actualiza el estado en la tabla
            JOptionPane.showMessageDialog(this, "Paciente desactivado correctamente",
                    "Información", JOptionPane.INFORMATION_MESSAGE);
        } else if (Estado.equalsIgnoreCase("Inactivo")) {
            Paciente.Activar_Paciente(ID); // Llama al método para activar el paciente
            model.setValueAt("Activo", Fila, Col); // Actualiza el estado en la tabla
            JOptionPane.showMessageDialog(this, "Paciente activado correctamente",
                    "Información", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Estado desconocido",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(this, "Debe seleccionar el registro a Activar/Desactivar",
                "Seleccione", JOptionPane.ERROR_MESSAGE);
    }
}

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        ActDes();   
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
    VerExpediente();       
    }//GEN-LAST:event_jButton5ActionPerformed

    
    public void Buscar(){
    
      String Buscar = txtBuscar.getText();
           
         model.setRowCount(0);

        String[] Header = {"No.", "Nombres", "Apellidos", "Peso", "Altura",
            "Edad", "Telefono", "Alergias", "Enfermedades", "Tipo Sangre", "Estado"};
        model.setColumnIdentifiers(Header);

        String[] Datos = new String[11];

        try {

            resultado = Conexion.consulta("Select * from Paciente where Nombres like '%"+Buscar+"%' "
                    + "or Apellidos like '%"+Buscar+"%'");

            while (resultado.next()) {
                Datos[0] = String.valueOf(resultado.getInt(1));
                Datos[1] = resultado.getString(2);
                Datos[2] = resultado.getString(3);
                Datos[3] = String.valueOf(resultado.getFloat(4));
                Datos[4] = String.valueOf(resultado.getFloat(5));
                Datos[5] = String.valueOf(resultado.getInt(6));
                Datos[6] = resultado.getString(7);
                Datos[7] = resultado.getString(8);
                Datos[8] = resultado.getString(9);
                Datos[9] = resultado.getString(10);

                boolean Estado = resultado.getBoolean(11);
                String Estate = "Inactivo";

                if (Estado) {
                    Estate = "Activo";
                }
                Datos[10] = Estate;

                model.addRow(Datos);
            }

        } catch (SQLException ex) {

        }

        jTable1.setModel(model);
      
}
    
    
    private void txtBuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyReleased
        Buscar();       
    }//GEN-LAST:event_txtBuscarKeyReleased

    public void VerExpediente() {
    int Fila = jTable1.getSelectedRow(); // Obtener la fila seleccionada
    if (Fila >= 0) {
        try {
            // Obtener el ID del paciente de la tabla
            int IDPaciente = Integer.parseInt(jTable1.getValueAt(Fila, 0).toString());
            
            // Crear instancia de la clase Expediente
            Expediente reporteExpediente = new Expediente();
            
            // Generar el PDF del expediente del paciente
            reporteExpediente.generarPDFExpediente(IDPaciente);
            
            JOptionPane.showMessageDialog(this, "El reporte del expediente se generó correctamente.",
                    "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al generar el expediente: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(this, "Debe seleccionar un paciente de la lista.",
                "Atención", JOptionPane.WARNING_MESSAGE);
    }
}

    DefaultTableModel model = new DefaultTableModel() {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }

    };
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField txtBuscar;
    // End of variables declaration//GEN-END:variables
}
