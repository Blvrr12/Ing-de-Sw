package Reportes;

import Clases.Conexion;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.filechooser.FileSystemView;
import com.itextpdf.text.Image;

public class HorarioPorMedicoMensual {
    
    private Conexion cn = new Conexion();
    
    public void generarPDFExpedienteMensual(int mes, int anio, int idMedico) {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            // Abrir la conexión aquí
            con = cn.getConexion();
            if (con == null || con.isClosed()) {
                System.out.println("La conexión a la base de datos está cerrada o es nula.");
                return;  // Finaliza si la conexión no es válida
            }

            // Fecha actual
            Date date = new Date();
            String url = FileSystemView.getFileSystemView().getDefaultDirectory().getPath();
            File salida = new File(url + "/ExpedienteMedico.pdf");

            // Verificar si el archivo puede escribirse en el directorio
            if (!salida.getParentFile().exists()) {
                System.out.println("Directorio no accesible: " + salida.getParentFile().getPath());
                return;
            }

            FileOutputStream archivo = new FileOutputStream(salida);
            Document doc = new Document();
            PdfWriter.getInstance(doc, archivo);
            doc.open();

            // Agregar logo
            try {
                Image img = Image.getInstance(getClass().getResource("/Images/logo_pdf.png"));
                img.scaleToFit(100, 100);
                img.setAlignment(Element.ALIGN_LEFT);
                doc.add(img);
            } catch (Exception e) {
                System.out.println("No se pudo cargar el logo: " + e.getMessage());
            }

            // Fecha de generación
            Paragraph fecha = new Paragraph();
            Font fechaFont = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.NORMAL, BaseColor.BLACK);
            fecha.add("Fecha de generación: " + new SimpleDateFormat("dd/MM/yyyy").format(date));
            doc.add(fecha);
            doc.add(Chunk.NEWLINE);

            // Título
            Font titleFont = new Font(Font.FontFamily.TIMES_ROMAN, 18, Font.BOLD, BaseColor.DARK_GRAY);
            Paragraph titulo = new Paragraph("Informe de Horario por Médico - Mes " + mes + " Año " + anio, titleFont);
            titulo.setAlignment(Element.ALIGN_CENTER);
            doc.add(titulo);
            doc.add(Chunk.NEWLINE);

            // Nueva consulta SQL
            String sql = """
                SELECT
                    CitaV.ID_Cita AS CitaV_ID_Cita,
                    CitaV.ID_Medico AS CitaV_ID_Medico,
                    CitaV.Nombres_Med AS CitaV_Nombres_Med,
                    CitaV.Apellidos_Med AS CitaV_Apellidos_Med,
                    CitaV.Fecha_Cita AS CitaV_Fecha_Cita,
                    DAY(CitaV.Fecha_Cita) AS CitaV_Dia_Cita,
                    CitaV.Hora_Cita AS CitaV_Hora_Cita,
                    WEEK(CitaV.Fecha_Cita, 1) AS CitaV_Semana_Cita,
                    CitaV.Nombres_Pac AS CitaV_Nombres,
                    CitaV.Apellidos_Pac AS CitaV_Apellidos,
                    CitaV.Estado AS CitaV_Estado
                FROM
                    CitaV
                WHERE 
                    MONTH(CitaV.Fecha_Cita) = ?  -- Filtrando por mes
                AND YEAR(CitaV.Fecha_Cita) = ?; -- Filtrando por año
            """;

            ps = con.prepareStatement(sql);
            ps.setInt(1, mes);  // Se pasa el parámetro del mes
            ps.setInt(2, anio);  // Se pasa el parámetro del año
            rs = ps.executeQuery();

            // Si se encuentran resultados
            if (rs.next()) {
                // Datos del médico
                Paragraph datosMedico = new Paragraph();
                Font subheadingFont = new Font(Font.FontFamily.TIMES_ROMAN, 14, Font.BOLD, BaseColor.DARK_GRAY);
                datosMedico.add(new Phrase("Médico: ", subheadingFont));
                datosMedico.add(rs.getString("CitaV_Nombres_Med") + " " + rs.getString("CitaV_Apellidos_Med"));
                datosMedico.add(Chunk.NEWLINE);
                datosMedico.add(new Phrase("ID Médico: ", subheadingFont));
                datosMedico.add(String.valueOf(rs.getInt("CitaV_ID_Medico")));
                datosMedico.add(Chunk.NEWLINE);
                doc.add(datosMedico);

                // Datos de la cita
                PdfPTable tablaConsulta = new PdfPTable(2);
                tablaConsulta.setWidthPercentage(100);
                tablaConsulta.setSpacingBefore(10f);
                tablaConsulta.setSpacingAfter(10f);

                Font boldFont = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD, BaseColor.BLACK);
                tablaConsulta.addCell(new PdfPCell(new Phrase("Fecha de Cita", boldFont)));
                tablaConsulta.addCell(rs.getString("CitaV_Fecha_Cita") != null ? rs.getString("CitaV_Fecha_Cita") : "No disponible");

                tablaConsulta.addCell(new PdfPCell(new Phrase("Día de la Cita", boldFont)));
                tablaConsulta.addCell(rs.getString("CitaV_Dia_Cita") != null ? rs.getString("CitaV_Dia_Cita") : "No disponible");

                tablaConsulta.addCell(new PdfPCell(new Phrase("Hora de la Cita", boldFont)));
                tablaConsulta.addCell(rs.getString("CitaV_Hora_Cita") != null ? rs.getString("CitaV_Hora_Cita") : "No disponible");

                tablaConsulta.addCell(new PdfPCell(new Phrase("Semana de la Cita", boldFont)));
                tablaConsulta.addCell(rs.getString("CitaV_Semana_Cita") != null ? rs.getString("CitaV_Semana_Cita") : "No disponible");

                tablaConsulta.addCell(new PdfPCell(new Phrase("Paciente", boldFont)));
                tablaConsulta.addCell(rs.getString("CitaV_Nombres") + " " + rs.getString("CitaV_Apellidos"));

                tablaConsulta.addCell(new PdfPCell(new Phrase("Estado de la Cita", boldFont)));
                tablaConsulta.addCell(rs.getString("CitaV_Estado") != null ? rs.getString("CitaV_Estado") : "No disponible");

                doc.add(tablaConsulta);

            } else {
                // Si no hay datos
                Paragraph noDatos = new Paragraph();
                noDatos.add("No se encontraron citas para el mes " + mes + " y año " + anio + " y médico con ID: " + idMedico);
                doc.add(noDatos);
            }

            // Espacio en blanco para firma
            doc.add(Chunk.NEWLINE);
            doc.add(Chunk.NEWLINE);

            // Firma del médico
            Paragraph firma = new Paragraph("Firma del Médico: ____________________________", new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.ITALIC, BaseColor.BLACK));
            firma.setAlignment(Element.ALIGN_LEFT);
            doc.add(firma);

            // Cierre del documento
            doc.close();

            // Abrir el archivo PDF generado
            Desktop.getDesktop().open(salida);

        } catch (Exception e) {
            System.out.println("Error al generar el expediente en PDF: " + e.getMessage());
            e.printStackTrace();
        } finally {
            // Cierre de los recursos
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (con != null && !con.isClosed()) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
