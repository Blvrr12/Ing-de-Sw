package Reportes;

import Clases.Conexion;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.filechooser.FileSystemView;

public class RecetaReport {
    Connection con;
    Conexion cn = new Conexion();
    PreparedStatement ps;
    ResultSet rs;

    public void generarPDFReceta(int ID_Cita) {
        try {
            // Fecha actual
            java.util.Date date = new java.util.Date();
            String url = FileSystemView.getFileSystemView().getDefaultDirectory().getPath();
            File salida = new File(url + "/RecetaMedica_" + ID_Cita + ".pdf");
            FileOutputStream archivo = new FileOutputStream(salida);
            Document doc = new Document();
            PdfWriter.getInstance(doc, archivo);
            doc.open();

            // Agregar logo
            try {
                Image img = Image.getInstance(getClass().getResource("/Images/logo_pdf.png"));
                img.scaleToFit(100, 100);
                img.setAlignment(Element.ALIGN_LEFT);
                doc.add(img);
            } catch (Exception e) {
                System.out.println("No se pudo cargar el logo: " + e.getMessage());
            }

            // Fecha
            Paragraph fecha = new Paragraph();
            Font negrita = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD, BaseColor.BLUE);
            fecha.add(Chunk.NEWLINE);
            fecha.add("Fecha de generación: " + new java.text.SimpleDateFormat("dd/MM/yyyy").format(date) + "\n\n");
            doc.add(fecha);

            // Encabezado
            Paragraph encabezado = new Paragraph();
            encabezado.setFont(negrita);
            encabezado.add("Receta Médica\n\n");
            encabezado.setAlignment(Element.ALIGN_CENTER);
            doc.add(encabezado);

            // Consulta SQL para obtener los detalles de la receta
            String sql = """
                SELECT
                    RecetaV.ID_Consulta,
                    RecetaV.Fecha_Cita,
                    RecetaV.NombresMed,
                    RecetaV.ApellidosMed,
                    RecetaV.NombreEsp,
                    RecetaV.Nombres,
                    RecetaV.Apellidos,
                    RecetaV.Receta,
                    RecetaV.ID_Cita
                FROM RecetaV
                WHERE RecetaV.ID_Cita = ?;
            """;

            con = cn.getConexion();
            ps = con.prepareStatement(sql);
            ps.setInt(1, ID_Cita);  // Usamos el ID_Cita como parámetro
            rs = ps.executeQuery();

            if (rs.next()) {
                // Información del médico
                Paragraph datosMedico = new Paragraph();
                datosMedico.add("Nombre Médico: " + rs.getString("NombresMed") + " " + rs.getString("ApellidosMed") + "\n");
                datosMedico.add("Especialidad: " + rs.getString("NombreEsp") + "\n\n");
                doc.add(datosMedico);

                // Información del paciente
                Paragraph datosPaciente = new Paragraph();
                datosPaciente.add("Nombre Paciente: " + rs.getString("Nombres") + " " + rs.getString("Apellidos") + "\n\n");
                doc.add(datosPaciente);

                // Fecha de la cita
                Paragraph fechaCita = new Paragraph();
                fechaCita.add("Fecha de Cita: " + rs.getString("Fecha_Cita") + "\n\n");
                doc.add(fechaCita);

                // Receta médica
                Paragraph receta = new Paragraph();
                receta.add("Receta:\n" + (rs.getString("Receta") != null ? rs.getString("Receta") : "No disponible") + "\n\n");
                doc.add(receta);
            } else {
                // Si no hay datos en la consulta
                Paragraph noDatos = new Paragraph();
                noDatos.add("No se encontraron datos para la cita con ID: " + ID_Cita);
                doc.add(noDatos);
            }

            // Cerrar el documento
            doc.close();

            // Abrir el archivo PDF generado
            Desktop.getDesktop().open(salida);

        } catch (Exception e) {
            System.out.println("Error al generar el expediente en PDF: " + e.getMessage());
        } finally {
            // Cerrar conexiones
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
