package Reportes;

import Clases.Conexion;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.filechooser.FileSystemView;

public class HorarioPorMedicoSemanal {
    private Connection con;
    private Conexion cn = new Conexion();
    private PreparedStatement ps;
    private ResultSet rs;

    public void generarPDFExpediente(int semana, int idMedico) {
        try {
            // Fecha actual
            Date date = new Date();
            String url = FileSystemView.getFileSystemView().getDefaultDirectory().getPath();
            File salida = new File(url + "/ExpedienteMedico.pdf");
            FileOutputStream archivo = new FileOutputStream(salida);
            Document doc = new Document();
            PdfWriter.getInstance(doc, archivo);
            doc.open();

            // Agregar logo
            try {
                Image img = Image.getInstance(getClass().getResource("/Images/logo_pdf.png"));
                img.scaleToFit(100, 100);
                img.setAlignment(Element.ALIGN_LEFT);
                doc.add(img);
            } catch (Exception e) {
                System.out.println("No se pudo cargar el logo: " + e.getMessage());
            }

            // Fecha de generación
            Paragraph fecha = new Paragraph();
            Font fechaFont = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.NORMAL, BaseColor.BLACK);
            fecha.add("Fecha de generación: " + new SimpleDateFormat("dd/MM/yyyy").format(date));
            doc.add(fecha);
            doc.add(Chunk.NEWLINE);

            // Título
            Font titleFont = new Font(Font.FontFamily.TIMES_ROMAN, 18, Font.BOLD, BaseColor.DARK_GRAY);
            Paragraph titulo = new Paragraph("Informe de Horario por Médico - Semana " + semana, titleFont);
            titulo.setAlignment(Element.ALIGN_CENTER);
            doc.add(titulo);
            doc.add(Chunk.NEWLINE);

            // Consulta SQL
            String sql = """
                SELECT
                    CitaV.ID_Cita AS CitaV_ID_Cita,
                    CitaV.ID_Medico AS CitaV_ID_Medico,
                    CitaV.Nombres_Med AS CitaV_Nombres_Med,
                    CitaV.Apellidos_Med AS CitaV_Apellidos_Med,
                    CitaV.Fecha_Cita AS CitaV_Fecha_Cita,
                    DAYNAME(CitaV.Fecha_Cita) AS CitaV_Dia_Cita,
                    CitaV.Hora_Cita AS CitaV_Hora_Cita,
                    WEEK(CitaV.Fecha_Cita) AS CitaV_Semana_Cita,
                    CitaV.Nombres_Pac AS CitaV_Nombres_Pac,
                    CitaV.Apellidos_Pac AS CitaV_Apellidos_Pac,
                    CitaV.Estado AS CitaV_Estado
                FROM
                    CitaV
                WHERE
                    WEEK(CitaV.Fecha_Cita) = ?  -- Filtrando por semana
                AND
                    CitaV.ID_Medico = ?;  -- Filtrando por ID Medico
            """;

            con = cn.getConexion();
            ps = con.prepareStatement(sql);
            ps.setInt(1, semana);  // Se pasa el parámetro de la semana
            ps.setInt(2, idMedico); // Se pasa el parámetro de ID Medico
            rs = ps.executeQuery();

            // Si se encuentran resultados
            if (rs.next()) {
                // Datos del médico
                Paragraph datosMedico = new Paragraph();
                Font subheadingFont = new Font(Font.FontFamily.TIMES_ROMAN, 14, Font.BOLD, BaseColor.DARK_GRAY);
                datosMedico.add(new Phrase("Médico: ", subheadingFont));
                datosMedico.add(rs.getString("CitaV_Nombres_Med") + " " + rs.getString("CitaV_Apellidos_Med"));
                datosMedico.add(Chunk.NEWLINE);
                datosMedico.add(new Phrase("ID Médico: ", subheadingFont));
                datosMedico.add(String.valueOf(rs.getInt("CitaV_ID_Medico")));
                datosMedico.add(Chunk.NEWLINE);
                doc.add(datosMedico);

                // Datos de la cita
                PdfPTable tablaConsulta = new PdfPTable(2);
                tablaConsulta.setWidthPercentage(100);
                tablaConsulta.setSpacingBefore(10f);
                tablaConsulta.setSpacingAfter(10f);

                Font boldFont = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD, BaseColor.BLACK);
                tablaConsulta.addCell(new PdfPCell(new Phrase("Fecha de Cita", boldFont)));
                tablaConsulta.addCell(rs.getString("CitaV_Fecha_Cita") != null ? rs.getString("CitaV_Fecha_Cita") : "No disponible");

                tablaConsulta.addCell(new PdfPCell(new Phrase("Día de la Cita", boldFont)));
                tablaConsulta.addCell(rs.getString("CitaV_Dia_Cita") != null ? rs.getString("CitaV_Dia_Cita") : "No disponible");

                tablaConsulta.addCell(new PdfPCell(new Phrase("Hora de la Cita", boldFont)));
                tablaConsulta.addCell(rs.getString("CitaV_Hora_Cita") != null ? rs.getString("CitaV_Hora_Cita") : "No disponible");

                tablaConsulta.addCell(new PdfPCell(new Phrase("Semana de la Cita", boldFont)));
                tablaConsulta.addCell(rs.getString("CitaV_Semana_Cita") != null ? rs.getString("CitaV_Semana_Cita") : "No disponible");

                tablaConsulta.addCell(new PdfPCell(new Phrase("Paciente", boldFont)));
                tablaConsulta.addCell(rs.getString("CitaV_Nombres_Pac") + " " + rs.getString("CitaV_Apellidos_Pac"));

                tablaConsulta.addCell(new PdfPCell(new Phrase("Estado de la Cita", boldFont)));
                tablaConsulta.addCell(rs.getString("CitaV_Estado") != null ? rs.getString("CitaV_Estado") : "No disponible");

                doc.add(tablaConsulta);

            } else {
                Paragraph noDatos = new Paragraph();
                noDatos.add("No se encontraron citas para la semana " + semana + " y médico con ID: " + idMedico);
                doc.add(noDatos);
            }

            // Espacio en blanco para firma
            doc.add(Chunk.NEWLINE);
            doc.add(Chunk.NEWLINE);

            // Firma del médico
            Paragraph firma = new Paragraph("Firma del Médico: ____________________________", new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.ITALIC, BaseColor.BLACK));
            firma.setAlignment(Element.ALIGN_LEFT);
            doc.add(firma);

            // Cierre del documento
            doc.close();

            // Abrir el archivo PDF generado
            Desktop.getDesktop().open(salida);
        } catch (Exception e) {
            System.out.println("Error al generar el expediente en PDF: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
